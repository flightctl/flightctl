#!/bin/bash

_psql () { psql --set ON_ERROR_STOP=1 "$@" ; }

# Ensure POSTGRESQL_MASTER_USER is treated as a superuser
if [ -n "${POSTGRESQL_MASTER_USER}" ]; then
    echo "Granting superuser privileges to ${POSTGRESQL_MASTER_USER}"
    _psql -c "ALTER ROLE ${POSTGRESQL_MASTER_USER} WITH SUPERUSER;"
fi
